# Predmet Praktikum Internet i Veb Tehnologije

## Sadrzaj spremista
 Ovde se nalazi projekat za predmet praktikum internet i veb tehnologije, tema projekta je Veb aplikacija za radnju za prodaju nameštaja
## Struktura spremista

* U direktorijumu [01-documentation](./01-documentation) se nalazi dokumentacija ovog projekta.
* U direktorijumu [02-resources](./02-resources) se nalaze dodatni materijali za ovaj projekat.
* U direktorijumu [03-back-end](./03-back-end) se nalazi kod projekta za API.
* U direktorijumu [04-front-end](./04-front-end) se nalazi front end deo aplikacije.