export default interface IModelAdapterOptions{
    loadParent: boolean;
    loadChildren: boolean;
}